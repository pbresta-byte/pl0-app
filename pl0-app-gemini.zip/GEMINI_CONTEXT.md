# PL0 app export

This archive contains the readable web app source for PL0, a Sarvato Bhadra Chakra analyzer.

Primary implementation: www/index.html
Static assets: www/manifest.json, www/sw.js, and www/icons/
Native wrapper configuration: capacitor.config.json

The app is a static Capacitor web app. Its HTML contains the CSS and JavaScript implementation inline, so no build step is required to inspect the core behavior.